
import { User, UserRole, Transaction, TransactionStatus, TransactionType, Message, PaymentSettings, WhatsAppSettings, AppSettings } from "../types";

const DEFAULT_AI_PROMPT = `Eres el asistente oficial de CasinoHub. 
Tu tono debe ser emocionante, profesional y persuasivo. Usa emojis de casino (🎰, 💰, 🔥).

Reglas:
1. Si el jugador pregunta cómo cargar saldo, pásale estos datos:
Titular: {{titular}}
Alias: {{alias}}
2. Si el jugador envía un comprobante, agradécele y dile que un cajero lo validará en segundos.
3. Si el jugador pregunta por su balance, dile que tiene \${{saldo}} disponibles.
4. Siempre termina invitándolo a jugar a sus slots favoritos.`;

const INITIAL_USERS: User[] = [
  {
    id: 'u1',
    phone: '+5491112345678',
    name: 'Juan Perez',
    balance: 15000,
    totalDeposited: 50000,
    totalWithdrawn: 35000,
    role: UserRole.ADMIN,
    status: 'ACTIVE',
    createdAt: new Date(Date.now() - 10000000).toISOString(),
    autopilotEnabled: true
  },
  {
    id: 'u2',
    phone: '+5491198765432',
    name: 'Maria Garcia',
    balance: 2500,
    totalDeposited: 10000,
    totalWithdrawn: 7500,
    role: UserRole.CASHIER,
    status: 'ACTIVE',
    createdAt: new Date(Date.now() - 5000000).toISOString(),
    autopilotEnabled: false
  }
];

const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 't1',
    userId: 'u1',
    amount: 5000,
    type: TransactionType.DEPOSIT,
    status: TransactionStatus.APPROVED,
    paymentMethod: 'Mercado Pago',
    externalRef: 'MP-99887766',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    processedBy: 'u2'
  }
];

const INITIAL_MESSAGES: Message[] = [
  {
    id: 'm1',
    senderPhone: '+5491198765432',
    receiverPhone: 'SYSTEM',
    text: 'Hola, acabo de enviar el comprobante.',
    timestamp: new Date().toISOString(),
    isIncoming: true
  }
];

const INITIAL_SETTINGS: AppSettings = {
  payment: {
    holderName: 'CASINO HUB OFICIAL',
    alias: 'casino.hub.mp',
    cvu: '0000003100012345678901',
    bankName: 'Mercado Pago',
    isActive: true,
    mpAccessToken: ''
  },
  whatsapp: {
    accessToken: '',
    phoneNumberId: '',
    wabaId: '',
    verifyToken: 'casino_hub_secure_token_2024',
    webhookUrl: 'https://api.casinohub.crm/webhooks/whatsapp',
    isConnected: false,
    globalAutopilot: false,
    aiPrompt: DEFAULT_AI_PROMPT,
    aiModel: 'gemini-3-flash-preview',
    aiStatus: 'ONLINE'
  }
};

export class StorageService {
  private static users = [...INITIAL_USERS];
  private static transactions = [...INITIAL_TRANSACTIONS];
  private static messages = [...INITIAL_MESSAGES];
  private static settings = { ...INITIAL_SETTINGS };

  static getUsers() { return this.users; }
  static getTransactions() { return this.transactions; }
  static getMessages() { return this.messages; }
  static getPaymentSettings() { return this.settings.payment; }
  static getWhatsAppSettings() { return this.settings.whatsapp; }

  static updatePaymentSettings(settings: PaymentSettings) {
    this.settings.payment = { ...settings };
  }

  static updateWhatsAppSettings(settings: WhatsAppSettings) {
    this.settings.whatsapp = { ...settings };
  }

  static addUser(user: User) { this.users.push(user); }
  
  static addMessage(msg: Message) {
    this.messages.push(msg);
  }

  static toggleUserAutopilot(userId: string) {
    const user = this.users.find(u => u.id === userId);
    if (user) {
      user.autopilotEnabled = !user.autopilotEnabled;
    }
  }

  static addTransaction(tx: Transaction) { 
    this.transactions.unshift(tx);
    const user = this.users.find(u => u.id === tx.userId);
    if (user && tx.status === TransactionStatus.APPROVED) {
      user.balance += (tx.type === TransactionType.DEPOSIT ? tx.amount : -tx.amount);
    }
  }

  static updateTransactionStatus(txId: string, status: TransactionStatus, adminId: string) {
    const tx = this.transactions.find(t => t.id === txId);
    if (tx && tx.status === TransactionStatus.PENDING) {
      tx.status = status;
      tx.processedBy = adminId;
      if (status === TransactionStatus.APPROVED) {
        const user = this.users.find(u => u.id === tx.userId);
        if (user) user.balance += (tx.type === TransactionType.DEPOSIT ? tx.amount : -tx.amount);
      }
    }
  }
}
